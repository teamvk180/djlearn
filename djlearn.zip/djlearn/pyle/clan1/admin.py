from django.contrib import admin
from .models import Attachment, Course, Department, Fee, Scholarship, Student

# Register your models here.

admin.site.site_header = 'My project'                    # default: "Django Administration"
admin.site.index_title = 'Features area'                 # default: "Site administration"
admin.site.site_title = 'HTML title from adminsitration' # default: "Django site admin"


admin.site.register(Student)
admin.site.register(Course)
admin.site.register(Scholarship)
admin.site.register(Attachment)
admin.site.register(Fee)
admin.site.register(Department)
