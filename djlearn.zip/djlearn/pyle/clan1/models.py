from django.contrib.auth.models import User
from django.db import models
import datetime


# Create your models here.

#admin user

class Course(models.Model):
      name = models.CharField(max_length=200)
      year = models.DateField() #year
      total_semester = models.IntegerField()

      def __str__(self):
          return self.name      

class Scholarship(models.Model):
      name = models.CharField(max_length=200)
      year = models.DateField() #year
      amount = models.IntegerField()
      paid = models.BooleanField(default=False)

      def __str__(self):
          return self.name                

class Department(models.Model):
      name = models.CharField(max_length=200)
      no_of_staffs = models.IntegerField()
      courses = models.ManyToManyField(
        Course, related_name='courses', blank=False)      
      started = models.DateField()
      def __str__(self):
          return self.name 

"""
class Employee(models.Model):
      name = models.CharField(max_length=200)
      emp_id = models.CharField(max_length=200)
      join_date = models.DateField()
      st_type = ('non teaching staff','teaching staff')
      st_position = ('teacher','cleark','suprend','auditor','cashier','store_keper','claning_staff','security_staff')
      staff_type = models.CharField(choices=st_type,max_length=300,default='non_teaching_staff')
      staff_position = models.CharField(choices=st_position,max_length=300,blank=False,default='staff')
      department = models.ForeignKey(Department,on_delete=models.CASCADE,null=True) 

class Employee_Salery(models.Model):
      employee_id = models.CharField(max_length=300)
      date = models.DateField(default=datetime.date.today)   
      amount = models.FloatField(null=True)

"""

class Fee(models.Model):
      register_no = models.CharField(max_length=400)
      name = models.CharField(max_length=200) #fee name
      amount = models.FloatField()
      balence = models.FloatField()

      def __str__(self):
          return self.name +'__' + self.register_no

class Attachment(models.Model):
      name = models.CharField(max_length=200)
      register_no = models.CharField(max_length=400)
      shelf_no = models.IntegerField()
      file = models.FileField(null=True)
      
      def __str__(self):
          return self.register_no

class Student(models.Model):
      name =models.CharField(max_length=200)
      register_no = models.CharField(max_length=400)
      father_name =models.CharField(max_length=200)
      mother_name =models.CharField(max_length=200)
      caste = models.CharField(max_length=200)
      dob =models.DateField()
      admin_name = models.ForeignKey(User,on_delete=models.CASCADE)
      about = models.TextField(max_length=400,blank=True)
      course = models.ForeignKey(Course,on_delete=models.CASCADE,null=True)
      #fee = models.ForeignKey(Fee,on_delete=models.CASCADE,null=True)
      #attachment = models.ForeignKey(Attachment,on_delete=models.CASCADE,null=True) 
      #scholarship = models.ForeignKey(Scholarship,on_delete=models.CASCADE,null=True)          
      department = models.ForeignKey(Department,on_delete=models.CASCADE,null=True)
      created = models.DateTimeField(auto_now_add=True)
      updated = models.DateTimeField(auto_now=True)

      def __str__(self):
          return self.name

