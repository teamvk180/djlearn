from django.urls import path
from django.views import View
from . import views

urlpatterns = [
    path('',views.home ,name="home"),
    path('shop',views.shop,name="shop"),
    path('shop/<int:pk>/',views.shop,name="shop"),
]
